/** Automatically generated file. DO NOT MODIFY */
package com.lau.loginapkuas;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}